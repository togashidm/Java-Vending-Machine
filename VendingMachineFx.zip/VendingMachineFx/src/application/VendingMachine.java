package application;

import java.util.ArrayList;

/**
   A vending machine.
*/
public class VendingMachine
{  
   private ArrayList<Product> products;
   public CoinSet coins; //total coins inserted
   public CoinSet currentCoins;
   public CoinSet changeCoins; //To allow change
   public CoinSet totalGivenChange; //Total coins given as change
   public double  roundChange;		//value of leftover

   /**
      Constructs a VendingMachine object.
   */
   public VendingMachine()
   { 
      products = new ArrayList<Product>();
      coins = new CoinSet();
      currentCoins = new CoinSet();
      changeCoins = new CoinSet(); //To allow change
      totalGivenChange = new CoinSet(); //To allow keep record of "virtual change"
   }
   
   
   //NEW METHOD called in the initialize()
   /**
    * Set product list in the vending machine
    * @param products
    */
   public void setProducts(ArrayList<Product> products) {
	this.products = products;
   }


   /**
      Gets the type of products in the vending machine.
      @return an array of products sold in this machine.
   */
   public Product[] getProductTypes()
   { 
      ArrayList<Product> types = new ArrayList<Product>();
      
      for (Product p : products)
         if (!types.contains(p)) types.add(p);

      Product[] r = new Product[types.size()];
      for (int i = 0; i < types.size(); i++)
         r[i] = types.get(i);
      return r;
   }

   /**
      Adds the coin to the vending machine.
      @param c the coin to add
   */
   public void addCoin(Coin c)
   { 
      currentCoins.addCoin(c);
   }

   
   
   //MODIFIED method
   /**
    *Buys a product from the vending machine.
   	* @param p the product to buy 
    * @return string message
    */
   	public String buyProduct(Product p)
	{ 
   		double diff;
	   for (int i = 0; i < products.size(); i++)
	   {
	      Product prod = products.get(i);
	      if (prod.equals(p))
	      {  
	         double payment = currentCoins.getValue(); // coins added by the user
	         payment = Math.round(payment*100.0)/100.0;
	         System.out.println("paying "+payment+" in coins");
	         System.out.println(p);
	         if (p.getPrice() <= payment)
	         {  
	            if (p.getQty()==1) products.remove(i); // removes when only one left
	            else products.get(i).setQty(p.getQty()-1);
	            
	            // create a set of coins for the change
	            diff=Math.round((payment-p.getPrice())*100)/100.0;
	            if (diff>=0) {
	            	changeCoins.removeAllCoins();//reset from any previous operation
	            	changeCoin(diff);
	            	System.out.println(diff);
	            	System.out.println("change: "+changeCoins.getValue());
	            }
	            totalGivenChange.addCoins(changeCoins); //stores "virtual coins give as change"
	            coins.addCoins(currentCoins); 
	            currentCoins.removeAllCoins(); 
	            return "Take your product.\nFor another item, start again!";
	         }
	         else
	         { 
	            return "Insufficient money.\nAdd "+
	            		Math.round((p.getPrice()-payment)*100.0)/100.0+" more";
	         }
	      }
	   }
	   return "No such product";
	}
	
   	//NEW method
   	/**
   	 * Split the change into coins and stored in the vending machine
   	 * and return any rounds or left over
   	 * @param change
   	 * 
   	 */
	public void changeCoin(double change){
		
		int E2, E1, fiftyCents, twentyCents, tenCents, fiveCents;
		int remainder;
		int changeHundreds = (int)(change*100);
		
		System.out.println("change*100: "+changeHundreds);
		// �2 coins
		E2 = changeHundreds/200;
		if (E2!=0) changeCoins.addCoin(new Coin(2.0, "2 Euro"));
		remainder = changeHundreds%200;
		System.out.println("E2 coins "+E2);
		
		// �1 coins
		E1 = remainder/100;
		if (E1!=0) changeCoins.addCoin(new Coin(1.0, "1 Euro"));
		remainder = remainder%100;
		System.out.println("E1 coins "+E1);
		
		// 50c coins
		fiftyCents = remainder/50;
		if (fiftyCents!=0) changeCoins.addCoin(new Coin(0.5, "50 cent"));
		remainder = remainder%50;
		System.out.println("50c coins "+fiftyCents);

		// 20c coins
		twentyCents = remainder/20;
		if (twentyCents!=0) changeCoins.addCoin(new Coin(0.2, "20 cent"));
		remainder = remainder%20;
		System.out.println("20c coins "+twentyCents);
		
		// 10c coins
		tenCents = remainder/10;
		if (tenCents!=0) changeCoins.addCoin(new Coin(0.1, "10 cent"));
		remainder = remainder%10;
		System.out.println("10c coins "+tenCents);

		// 5c coins
		fiveCents = remainder/5;
		if (fiveCents!=0) changeCoins.addCoin(new Coin(0.05, "5 cent"));
		remainder = remainder%5;
		System.out.println("5c coins "+fiveCents);
		
		System.out.println("remainder(cts): "+remainder);
		roundChange =remainder/100;
	}
   	
   	
   	//New method
	/**
	 * 	(re)load the vending machine with the existent product
	 * @param Product p
	 * @param int qty
	 */
	public void loadProduct(Product p, int qty) {
		   for (int i = 0; i < products.size(); i++) {
		      Product prod = products.get(i);
		      if (prod.equals(p)) {
		    	  products.get(i).setQty(qty);
		      }		   
		   }
	}
	
		

	//New method
   /**
    * Adds a product to the vending machine. ## MODIFIED ##
    * if there is not already one
    * @param p the product to add
	*/
	public boolean addProduct(Product p)
	 {	
		Product prod;
		System.out.println(products.size());
	   for (int i = 0; i < products.size(); i++) {
		   	//selecting an item from the product list
		    prod = products.get(i);

		    //check if there is an item in the same location
		    if (prod.getLocation().equalsIgnoreCase(p.getLocation())) return false;
		    
		    else {
			    //check if there is already same product description and price, OR same product description <> price
			    if (prod.equals(p) || prod.getDescription().equalsIgnoreCase(p.getDescription())) return false;
		    	}
		   }
 	  products.add(p);
 	  return true;
	 }
   
	
	

	 /**
	  *  Adds a product to the vending machine.
	  *  @param p the product to add
	  *  @param quantity the quantity
	  */
	public void addProduct(Product p, int quantity)
	  {
	     for (int i = 0; i < quantity; i++)
	        products.add(p);
	  }
	 
   
   /**
    * Removes the money from the vending machine.
    * @return the amount of money removed
    */
	public double removeMoney()
	{  
      double r = coins.getValue();
      coins.removeAllCoins();
      return r;
	}
}
