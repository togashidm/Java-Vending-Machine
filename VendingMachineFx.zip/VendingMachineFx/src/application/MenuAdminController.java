package application;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class MenuAdminController implements Initializable{

    @FXML
    private ListView<Product> productListView;

    @FXML
    private TextField npDescription;

    @FXML
    private TextField npPrice;

    @FXML
    private TextField npLocation;

    @FXML
    private TextField npQty;

    @FXML
    private Label userLabel;
    
    @FXML
    private Label output;

    // declaring the item selected from the ListView
    private Product productItemSelected;
    
    //get the username of user for the session
    private User user=LoginController.getLoggedUser();

    //get the VendingMachine instance from the LoginController
    private VendingMachine machine = LoginController.getMachine();

    
    // loading the product list
    private List<Product> productList = (List<Product>) FileService.getList(new Product());
		
	
	//create an observable list (from where the item to be selected):
	private ObservableList<Product> observList = FXCollections.observableList(productList);
	
    // lock the system when the machine is shutdown 
	private boolean shutDown = false;
	
	//"itemCheck" variable allows to reload
	private boolean reloadAllowed=false;

    
	/**
	 * loading the productList in ListView		
	 * @param location
	 * @param recources
	 */
    public void initialize(URL location, ResourceBundle recources) {
    	if (!shutDown) {
	    	System.out.println("initialize() called");
	    	
	    	userLabel.setText("Welcome "+ user.username);
	    	productListView.setItems(observList);
	    	    	
			//load the machine with the productList 
			machine.setProducts((ArrayList<Product>) productList);
			System.out.println(productList);System.out.println();
			
			//leave fields editable
			activateTextField(true);

    		}
    	}


    /**
     * Select an item from the ListView
     * @param event
     */
    public void selectItem(ActionEvent event) {
    	if (!shutDown) {
	    	System.out.println("\nselectItem() called");
	    	try {
				//get the information of the selected item
				productItemSelected = productListView.getSelectionModel().getSelectedItem();
				System.out.println(productItemSelected);
				output.setText(productItemSelected.toString()+"\n change the quantity, and reload");

				//Display the description, location, price and quantity of the selected item
				npDescription.setText(productItemSelected.getDescription());
				npDescription.setStyle("-fx-text-inner-color: grey;");
				npLocation.setText(productItemSelected.getLocation());
				npLocation.setStyle("-fx-text-inner-color: grey;");
				npPrice.setText(""+productItemSelected.getPrice());
				npPrice.setStyle("-fx-text-inner-color: grey;");
				//npQty.setText(""+productItemSelected.getQty());
				
				//only leave quantity field editable
				activateTextField(false);
				output.setText("Input quantity and reload");
				reloadAllowed=true;
				} 
	    	catch (Exception ex) {
				System.out.println("Exception generated when selecting Item "+ex);
				output.setText("Select an Item and reload");
				}
	    	}
    	}
    
    
    public void activateTextField(boolean flag) {
    	npDescription.setEditable(flag);
    	npLocation.setEditable(flag);
    	npPrice.setEditable(flag);
    }

    
    /**
     * Administrator to add a new item
     * @param event
     */
    public void addItem(ActionEvent event)  {
    	if (!shutDown) {
	    	System.out.println("addItem() called");
			//leave fields editable
			activateTextField(true);
	    	
	    	String description = npDescription.getText();
	    	String location = npLocation.getText().toUpperCase();
	    	
	    	
	    	double price;
			int qty;
			
			try {
				price = Double.parseDouble(npPrice.getText());
				qty = Integer.parseInt(npQty.getText());
		    	Product p = new Product(description,location,price,qty);
		    	System.out.println(p);
		    	
		    	//adding the item to vending machine
		    	if (machine.addProduct(p)) {
		    		output.setText("New product added !");
			    	npDescription.setText("");
			    	npLocation.setText("");
			    	npPrice.setText("");
			    	npQty.setText("");
	    	
					//update product list in the file
				    List<Product> tempList = new ArrayList<Product>();
				    Collections.addAll(tempList, machine.getProductTypes());
			
				    //updating new list
					productList = tempList;
			
					//updating ListView
					observList = FXCollections.observableList(productList);
					productListView.setItems(observList);
			    	
					//allows to edit the text fields
					activateTextField(false);
					
					//activate reload function
					reloadAllowed=true;
					
			    	}
		    	else {
		    		output.setText("Please, check if there is already this product "		    	
		    						+ "or there is another product in the same location");
		    		
		    		}

				} 
			catch (NumberFormatException ex) {
				System.out.println("Exception generated when adding Item "+ex);
				output.setText(""+ex);
				}
			

			}
    	}

    
    /**
     * It (re)load by quantity, allows price changes and description
     * 
     * @param event
     */
    public void loadProductItem(ActionEvent event) {
    	if (!shutDown && reloadAllowed) {
	    	System.out.println("loadProductItem() called");
	    	
	    	
	    	try {
	    		
		    	String description = npDescription.getText();
		    	String location = npLocation.getText();
	    		
				if (Integer.parseInt(npQty.getText())<=productItemSelected.getQty()) {
					output.setText("Increase the quantity");
					}

				else {
					double price = Double.parseDouble(npPrice.getText()); 
					int qty = Integer.parseInt(npQty.getText()); 
					Product p = new Product(description,location,price,qty);
					System.out.println(p);
					
			    	//loading the item to vending machine
					machine.loadProduct(p, qty);
					
					//update product list in the file
					List<Product> tempList = new ArrayList<Product>();
					Collections.addAll(tempList, machine.getProductTypes());
		
					//updating new list
					productList = tempList;
					
					//updating ListView
					observList = FXCollections.observableList(productList);
					productListView.setItems(observList);
					System.out.println();
					
			    	npDescription.setText("");
			    	npLocation.setText("");
			    	npPrice.setText("");
			    	npQty.setText("");

					output.setText("Reload another item\n or add a new item");

					
					//leave fields editable
					activateTextField(true);
					
					}
	    		}
	    	catch (NumberFormatException ex) {
					System.out.println("Exception generated when adding Item "+ex);
					output.setText("Input the right values\n"+ex);
				}
	    	catch (NullPointerException ex) {
					System.out.println("Exception generated when adding Item "+ex);
					output.setText("Input the right values\n"+ex);
				}

    		}
    	}
    
    /**
     * This method shutdown the Vending Machine by storing all product information
     * to the product file, and exit the application.
     * @param event
     */
    
    public void shutDown(ActionEvent event) {
    	System.out.println("shutDown() called");
    	
    	//saving the product list to the file
		Product.updateProductList(productList);
		
		System.out.printf("\nCoins in the machine: %.2f",
		machine.coins.getValue());
		System.out.printf("\nCoins given as change in the machine: %.2f",
				machine.totalGivenChange.getValue());System.out.println("\n");
		
		//updating user balance - Note that it is discount the coins given to change
		user.balance=machine.coins.getValue()-machine.totalGivenChange.getValue(); 
		//user.balance=machine.coins.getValue();
		//reset coins in the machine
		machine.removeMoney();
    	//update file
		user.updateUserList(user);
		//clear the listview
		productListView.getItems().clear();
		//reset the text fields
		clearOutput(null);
    	userLabel.setText("Vending Machine OFF");
		output.setText("Machine Shutdown");
		shutDown=true;
		}
    
    
    /**
     * Method to clear all the text fields
     * @param event
     */
    @FXML
    public void clearOutput(ActionEvent event) {
    	if (!shutDown) {
    		
	    	output.setText(""); 
	    	npDescription.setText("");
	    	npLocation.setText("");
	    	npPrice.setText("");
	    	npQty.setText("");
    		}
    	}    

    
    
	/**
	 * Allows the user to logout the machine and return to the login screen
	 * @param event
	 * @throws IOException
	 */
	public void logout (ActionEvent event) throws IOException {
		if (shutDown) {
			Parent rootMenu = FXMLLoader.load(getClass().getResource("Login.fxml"));
			Scene menuScene = new Scene(rootMenu,800,600);
			menuScene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(menuScene);
			window.setTitle("Login");
			window.show();
			System.out.println("Showing home scene");
		}
	}

    
    
    
    /**
     * Method to exit the application
     * @param event
     */
    public void exit(ActionEvent event) {
    	//logoutBt.setOnAction(e->{System.exit(0);});
    	System.exit(0);
    	}
}
