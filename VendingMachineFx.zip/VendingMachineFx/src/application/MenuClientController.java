package application;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

public class MenuClientController implements Initializable {

    @FXML
    private ListView<Product> productListView;

    @FXML
    private Label insertedCoin;
    
    @FXML
    private Label output;

    @FXML
    private Label userLabel;
    
    // declaring the item selected from the ListView
    private Product productItemSelected;
    
    //get username of user for the session
    private User user=LoginController.getLoggedUser();
    
    //get the VendingMachine instance from the LoginController 
    private VendingMachine machine = LoginController.getMachine();

    // loading the product list
    private List<Product> productList = (List<Product>) FileService.getList(new Product());		
		
	//create an observable list (from where the item to be selected):
	private ObservableList<Product> observList = FXCollections.observableList(productList);

	//"itemCheck" variable allows to insert the coins
	private boolean itemChecked=false;
    
    
	/**
	 * loading the productList in ListView		
	 * @param location
	 * @param recources
	 */
    public void initialize(URL location, ResourceBundle recources) {
    	System.out.println("initialize() called");
    	    	   	
    	userLabel.setText("Welcome "+ user.username+"\nCurrent balance (�): "+
    			String.valueOf(String.format("%.2f",user.balance)));
    	productListView.setItems(observList);

		//load the machine with the productList
		machine.setProducts((ArrayList<Product>) productList);
		System.out.println(productList);System.out.println();
		
		//Set instruction on screen
		output.setText("1. Click item in the list and 'Select'\n"
				+ "2. Insert the requested amount\n"
				+ "3. Click on 'Buy'");
		}
    
	
	/**
	 * Select the item in the ListView
	 * @param event - clicking on Select button
	 */
	public void productSelection(ActionEvent event) {
		System.out.println("productSelection() called");
				
		try {
			//get the information of the selected item
			productItemSelected = productListView.getSelectionModel().getSelectedItem();
			output.setText(productItemSelected.toString()+
					"\n\nInsert the required amount and 'Buy'");
			itemChecked=true;
			} 
    	catch (Exception ex) {
			System.out.println("Exception generated when selecting Item "+ex);
			output.setText("Click on the item list, first");
			}
		}
	

	/**
	 * User select to buy the selected item. It will check if there is enough credit to
	 * proceed the purchased or not. Also it will check if the amount of coins select is 
	 * the same or above of the selected item price.
	 * @param event
	 */
	public void productBuy(ActionEvent event) {
		System.out.println("productBuy() called\n");
		
		if (itemChecked) {
				
			//inserted coins for selected purchased
			double currentCoins = Math.round(machine.currentCoins.getValue()*100)/100.0;
			user.balance = Math.round(user.balance*100)/100.0;
			
			//double diff =  Math.round((user.balance-currentCoins)*100)/100.0;
			
			double diff =  Math.round((user.balance-productItemSelected.getPrice())*100)/100.0;
			
			//implemented to give change 
			double change; 
				
			System.out.println("** total coins inserted: "+currentCoins);
			System.out.println("** current balance: "+user.balance);
			System.out.println("** diff: "+diff);
				
			if (diff<0) {
				output.setText("Not enough credit");
				//remove all the current coins added by the user
				machine.currentCoins.removeAllCoins();
				}
				 
				
			else {
				
				//buying the product item in machine #calls buyProduct() method
				String msg = machine.buyProduct(productItemSelected);
				output.setText(msg);
				
				//this allows the user to continue to insert coins to match product price
				if (msg.contains("Take")) {
											
					System.out.printf("\nCoins in the machine: %.2f",
					machine.coins.getValue());
					System.out.printf("\nCoins given as change in the machine: %.2f",
							machine.totalGivenChange.getValue());System.out.println("\n");
					
					//if user insert value above product price, it gives a change
					change= Math.round((machine.changeCoins.getValue()+ machine.roundChange)*100)/100.0;
						
					//updating user balance
					user.balance -= currentCoins;
					user.balance += change;
						
					//updated balance in the machine display
			    	userLabel.setText("Welcome "+ user.username+"\nCurrent balance (�): "+
			    			String.valueOf(String.format("%.2f",Math.abs(user.balance))));
				
			    	//message if any change
			    	if (change!=0 && user.balance>0) insertedCoin.setText("Excess of "+change+" returned");
			    	else insertedCoin.setText("");
			    	
					//update user balance in the file
					user.updateUserList(user);
						
					//update product list in the file
				    List<Product> tempList = new ArrayList<Product>();
				    Collections.addAll(tempList, machine.getProductTypes());
		
				    //updating new list
					productList = tempList;
					Product.updateProductList(productList);
					System.out.println(productList);
		
					//updating ListView
					observList = FXCollections.observableList(productList);
					productListView.setItems(observList);
					System.out.println();	
					//reset to display
					
						
					itemChecked=false;
					}
				else itemChecked=true;
				}
			}			
		else output.setText("Click item on the list, and 'Select'" );
		}
	
	
    @FXML
    public void clearOutput(ActionEvent event) {
    	output.setText(""); 
    	insertedCoin.setText("");
    	//remove coins inserted of not completed purchase
    	machine.currentCoins.removeAllCoins();
    	}    

	
	
	
	//insert the coin value to machine
	public void bt_5c(ActionEvent event){
		if (itemChecked) {
			machine.addCoin(new Coin(0.05, "5 cent"));
			insertedCoin.setText("Total:\t"+String.valueOf(String.format("%.2f",machine.currentCoins.getValue()))+" Euro");
			}
		}

	public void bt_10c(ActionEvent event){
		if (itemChecked) {
			machine.addCoin(new Coin(0.1, "10 cent"));
			insertedCoin.setText("Total:\t"+String.valueOf(String.format("%.2f",machine.currentCoins.getValue()))+" Euro");	
			}
		}

	public void bt_20c(ActionEvent event){
		if (itemChecked) {
			machine.addCoin(new Coin(0.2, "20 cent"));
			insertedCoin.setText("Total:\t"+String.valueOf(String.format("%.2f",machine.currentCoins.getValue()))+" Euro");
			}
		}
	
	public void bt_50c(ActionEvent event){
		if (itemChecked) {
			machine.addCoin(new Coin(0.5, "50 cent"));
			insertedCoin.setText("Total:\t"+String.valueOf(String.format("%.2f",machine.currentCoins.getValue()))+" Euro");
			}
		}

	public void bt_1E(ActionEvent event){
		if (itemChecked) {
			machine.addCoin(new Coin(1.0, "1 Euro"));
			insertedCoin.setText("Total:\t"+String.valueOf(String.format("%.2f",machine.currentCoins.getValue()))+" Euro");
			}
		}
	
	public void bt_2E(ActionEvent event){
		if (itemChecked) {
			machine.addCoin(new Coin(2.0, "2 Euro"));
			insertedCoin.setText("Total:\t"+String.valueOf(String.format("%.2f",machine.currentCoins.getValue()))+" Euro");
			}
		}
	
	
	/**
	 * Allows the user to logout the machine and return to the login screen
	 * @param event
	 * @throws IOException
	 */
	public void logout (ActionEvent event) throws IOException {
		Parent rootMenu = FXMLLoader.load(getClass().getResource("Login.fxml"));
		Scene menuScene = new Scene(rootMenu,800,600);
		menuScene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(menuScene);
		window.setTitle("Login");
		window.show();
		System.out.println("Showing home scene");	
	}
	
}
