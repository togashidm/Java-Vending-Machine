package application;

public class Snack extends Product {
	
	public Snack(String aDescription, String aLocation, double aPrice, int aQty) {
		super(aDescription, aLocation, aPrice, aQty);
	
		
		}
	
	}
	

