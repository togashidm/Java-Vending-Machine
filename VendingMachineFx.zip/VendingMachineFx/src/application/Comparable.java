package application;

public interface Comparable {

	 boolean equals(Product other); //modified from Object to Product
	 
	 
}
