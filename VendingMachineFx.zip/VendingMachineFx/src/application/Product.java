package application;

import java.util.List;

public class Product implements Comparable
{
	private String description;
	private String location;
	private double price;
	private int qty;
	private String filename="Product.dat";
		   

	/**
	 Constructs a Product object
	 @param aDescription the description of the product
	 @param aLocation the location of the product
	 @param aPrice the price of the product
	 @param aQty the quantity of the product
	*/
	public Product(String aDescription, String aLocation, double aPrice, int aQty)
	   {
		description = aDescription;
		price = aPrice;
		location = aLocation;
		qty = aQty;
		}
		   
	//blank constructor to call the methods
	Product(){}
		   
		   
	/**
	  Gets the description.
	  @return the description
	*/
	public String getDescription()
	   { 
	    return description;
	   }
		   
	/**
	 Gets the price.
	 @return the price
	*/
	public double getPrice()
	   {  
	    return price;
	   }

	 //New method
	/**
	  * Gets the quantity of the product
	  * @return
	*/
	public int getQty() {
		 return qty;
	 }

	  //New method
	  /**
	   * Sets the quantity of the product
	   */
	public void setQty(int qty) {
	  this.qty = qty;
	  }

   //New method
	/**
	 * Gets the location of the product
	 * @return
	 */
	public String getLocation() {
		   return location;
	   }
		   
	//New method
	/**
	 * Gets the product filename
	 * @return
	 */
	public String getFilename() {
		return filename;
		}
			
	/**
	 * update the product list from the ListView to the external file
	 * @param productList
	 */
	static void updateProductList(List productList) {
				System.out.println("updateProductList() in Product called");
				FileService.writeList(productList);
				}

	//modified to be case insensitive
	/**
	  Determines of this product is the same as the other product.
	  @param other the other product
	  @return true if the products are equal, false otherwise
	*/
	@Override
	public boolean equals(Product other)
	   { 
		if (other == null) return false;
	     	Product b = (Product) other;
		    return description.toLowerCase().equals(b.description.toLowerCase()) && price == b.price;
		    }
		   

	/**
	  Formats the product's description and price.
	*/
	//code modified to include location
	public String toString()
	   { 
	     return description + " @ �" + price + " location: "+location+" qty: "+qty;
	   }

}
