package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public abstract class FileService {
	
    protected String line = "";
    protected String cvsSplitBy = ",";

	/**
	 * Get the instance and return a read list from external file. 
	 * @param instance
	 * @return list of users or product
	 */
    public static Object getList(Object instance) {
    	System.out.println("getList() called");
	   	
    	String className = instance.getClass().getSimpleName();
    	
    	if (className.equals("Product")) 
    		return new FileProduct().readProductFile(new Product().getFilename());
    	
    	else if (className.equals("Administrator")) 
    		return new FileUser().readUserFile(new Administrator().getFilename());
    	
    	else if (className.equals("Client")) 
    		return new FileUser().readUserFile(new Client().getFilename());
    	
    	return null; 
    	}
	
    /**
     * Export a list of instance to the respective external file.
     * @param listOfInstances
     */
    public static void writeList(List listOfInstances) {
    	System.out.println("writeList() called");
    	
    	//need to test for null or empty
    	String className = listOfInstances.get(0).getClass().getSimpleName(); 
    	
    	if (className.equals("Product"))  
    		new FileProduct().writeProductFile(listOfInstances);
    	
    	else if (className.equals("Administrator")) 
    		new FileUser().writeUserFile(listOfInstances);
    	
    	else if (className.equals("Client")) 
    		new FileUser().writeUserFile(listOfInstances);
    	}
}



   class FileProduct extends FileService {
	   
	   
	   /**
	    * This method reads a external product file and return a list of products 
	    * @param String csvFile
	    * @return List<Product> productList
	    */
	   List<Product> readProductFile(String csvFile) {
		   System.out.println("readProductFile() called");
		   
	       List<Product> productList = new ArrayList<Product>();
	       try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
	           while ((line = br.readLine()) != null) {
	                // use comma as separator
	                String[] data = line.split(cvsSplitBy);
	                productList.add(new Product(data[0],data[1],Double.parseDouble(data[2]),Integer.parseInt(data[3])));
	                }
	            }
	       catch (IOException e) {
	        	System.out.println(e+" problem in loading the file");
	        	}
	       return productList;
        }
    
    
	   
	   /**
	    * This method write a product list to the external product file
	    * @param List<Product> productList
	    */
        void writeProductFile(List<Product> productList) {    
        	System.out.println("writeProductFile() called");
	    
        	try {
				//establish path to the file:
				File myFile = new File(new Product().getFilename());//a relative path
	
				//creates the file:
				myFile.createNewFile();

				//created file writer object:
				FileWriter fwriter =new FileWriter(myFile);

				//building the contents
				StringBuilder sb = new StringBuilder();
				for (Product i:productList) {
					sb.append(i.getDescription());
					sb.append(",");
					sb.append(i.getLocation());
					sb.append(",");
					sb.append(String.valueOf(String.format("%.2f",i.getPrice())));			
					sb.append(",");
					sb.append(i.getQty());
					sb.append("\n");
					}
				//write updated user list 	
				fwriter.write(sb.toString());
				//flushes the text to the file
				fwriter.flush();
				//closes the file
				fwriter.close();
				} 
			catch (IOException e) {
				System.out.println("Problem in writing the file"+e);
				}
			}
   	}
  
  
  class FileUser extends FileService{
	  
	  
	  /**
	   * This method reads the respective external user file and return a list of users
	   * @param csvFile
	   * @return
	   */
	  List<User> readUserFile(String csvFile) {
		  System.out.println("readUserFile() called");
    	
	       List<User> userList = new ArrayList<User>();
	       try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
	            while ((line = br.readLine()) != null) {
	                // use comma as separator
	                String[] data = line.split(cvsSplitBy);
	                //if the administrator file has a balance this block is not useful
	                if (data.length==3) {
		                userList.add(new Client(data[0],Double.parseDouble(data[1]),data[2]));
	                	}
	                else {
	                	userList.add(new Administrator(data[0],Double.parseDouble(data[1]),data[2]));
	                	}
	                }
	            } 
	        catch (IOException e) {
	        	System.out.println("problems in reading the file "+e);
	        	}
			return userList;
			}

    
	  /**
	   * This method write a respective user list to the external user file
	   * @param usersList
	   */
	  void writeUserFile(List<User> usersList) {
		  	/* if the administrator format become different I need to distinguish between them
    			from the start */
		  	System.out.println("writeProductFile() called");
		  
		  	try {
		  		//need to test for null or empty
		    	String className = usersList.get(0).getClass().getSimpleName(); 
		    	String filename = null;
		    	
		    	if (className.equals("Client")) filename=new Client().getFilename();
		    	if (className.equals("Administrator")) filename=new Administrator().getFilename();
		    	
		    	//establish path to the file:
				File myFile = new File(filename);//a relative path

				//creates the file:
				myFile.createNewFile();
			
				//created file writer object:
				FileWriter fwriter =new FileWriter(myFile);

				//building the contents
				StringBuilder sb = new StringBuilder();
				for (User i:usersList) {
					sb.append(i.username);
					sb.append(",");
					sb.append(String.valueOf(String.format("%.2f",Math.abs(i.balance))));
					sb.append(",");
					sb.append(i.password);
					sb.append("\n");
					}
				//write updated user list 	
				fwriter.write(sb.toString());
				//flushes the text to the file
				fwriter.flush();
				//closes the file
				fwriter.close();
		  		}
			catch (IOException e) {
				System.out.println("Problem in writing the file"+e);
				}
			}
  	}

