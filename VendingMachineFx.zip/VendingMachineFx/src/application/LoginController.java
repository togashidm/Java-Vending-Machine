package application;

import java.io.IOException;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class LoginController {
	@FXML
	private Label statusField;
	
	@FXML
	private TextField usernameField;

	@FXML
	private TextField passwordField;

	@FXML
	private Label text;
	
	//to set the logged user
	private static User loggedUser;
	
    //Creating the VendingMachine instance
	private static VendingMachine machine = new VendingMachine();
	
	
	/**
	 * To get the logged user
	 * @return
	 */
	public static User getLoggedUser() {
		return loggedUser;
		}
	
	/**
	 * To get the VendingMachine instance
	 * @return
	 */
	public static VendingMachine getMachine() {
			return machine;
		}


	/**
	 * let a valid user enter into the system.
	 * @param event
	 * @throws IOException
	 */
	public void login(ActionEvent event) throws IOException {
		
		String logname = usernameField.getText();
		String logpsw  = passwordField.getText();
		
		if (checkUser(logname,logpsw,new Administrator())==0) {
			System.out.println("here in admin entry loginController");
			statusField.setText("login success");
			newPage(event,"MenuAdmin.fxml");
			System.out.println("Showing MenuAdmin logingcontroller");
			}
		else if (checkUser(logname,logpsw,new Client())==1) {
			statusField.setText("login success");
			newPage(event,"MenuClient.fxml");
			System.out.println("Showing MenuClient");
			}
			
		else if (checkUser(logname,logpsw,new Client())==-1) {
			statusField.setText("No balance!");
			System.out.println("Client with no balance");
			}				
		else {
			statusField.setText("Invalid login!");
		 	}
		}
	
	
	/**
	 * method that identify the user as client or administrator,
	 * by loading the corresponding file, and it checks if the log informations are valid.
	 * 
	 * @param username
	 * @param password
	 * @param user
	 * @return -2 if it is a nonuser, -1 if it is a user but no credits, 0 if it is administrator. 
	 * 			otherwise a client with balance
	 */
	public static int checkUser(String username, String password, User user) {
		System.out.println("checkUser() called");
		
		//check and return the user type and state
		for (User i: (List<User>)FileService.getList(user)) { 
			
			if (i.username.equals(username) && i.password.equals(password) 
					&& user instanceof Administrator) {
				 loggedUser= new Administrator(username,password);
				 System.out.println("Adminstrator logged here");

				return 0;
				}
			
			else if (i.username.equals(username) && i.password.equals(password)) {
				if (i.balance > 0) {
					loggedUser=i;
					System.out.println("Client logged here");
					return 1;
					}
				else return -1;
				}
			}
		return -2;
		}

	
	/**
	 * Creates an new Scene and load the fxml file for the scene
	 * @param event
	 * @param fxmlFile
	 * @throws IOException
	 */
	public void newPage (ActionEvent event, String fxmlFile) throws IOException {
		Parent rootMenu = FXMLLoader.load(getClass().getResource(fxmlFile));
		Scene menuScene = new Scene(rootMenu,800,600);
		menuScene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(menuScene);
		window.setTitle(loggedUser.username);
		window.show();
		}
	
	/**
	 * Allows to exit the application
	 * @param event
	 */
    public void exit(ActionEvent event) {
    	//logoutBt.setOnAction(e->{System.exit(0);});
    	System.exit(0);
    	}
	
}
