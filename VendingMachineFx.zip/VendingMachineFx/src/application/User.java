package application;

import java.util.List;

public abstract class User {
	protected String username;
	protected String password;
	protected double balance;
	
	
	abstract public String getFilename();
	
	
	/**
	 * This method is to update the user current balance
	 * @param user
	 */
	public void updateUserList(User user) {
		System.out.println("udateUserList() called");
		
		int index = 0,counter=0;
		
		//getting the user list from the file
		List<User>temp = (List<User>) FileService.getList(user);
		
		//find the user index position in the list
		for (User i: temp) {
			if (i.username.equals(username) && i.password.equals(password)) {
				index=counter;
				}
			counter++;
			}
		//remove the user from the list
		temp.remove(index);
		//add the user with updated balance to the list
		temp.add(user);
		//update the user external file
		FileService.writeList(temp);
	}
	
	/**
	 * method to print the instance informations
	 */
	public String toString() {
		return username+" "+password+" "+balance;			
	}
}


	class Client extends User {
		
		//External filename for the client class
		private String filename="Clients.dat";
		
		Client(String username, double balance, String password){
			this.username=username;
			this.password=password;
			this.balance=balance;
		
			}
		
		// blank constructor
		Client(){};

		/**
		 * to get the client filename
		 */
		@Override
		public String getFilename() {
			return filename;
		}
	}
		
		
	class Administrator extends User {
		
		//External filename for the administrator class		
		private String filename="Admin.dat";
		
		Administrator(String username, double balance, String password){
			this.username=username;
			this.password=password;
			this.balance=balance;
			}
		
		Administrator(String username, String password){
			this.username=username;
			this.password=password;
			}
		
		//blank constructor
		Administrator(){};

		
		@Override
		public String getFilename() {
			return filename;
		}
	
	}
	

